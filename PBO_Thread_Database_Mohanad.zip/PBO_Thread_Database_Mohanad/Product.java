/**
 * Product - model class for one row of the "products" table.
 *
 * Author: MOHANAD R. M. ABUMATTAR (F1D02411002) - Class 5A, PBO
 * Case study: Thread and Database in Java.
 */
public class Product {

    private int id;
    private String name;
    private String category;
    private double price;
    private int stock;

    public Product() {
    }

    public Product(String name, String category, double price, int stock) {
        this.name = name;
        this.category = category;
        this.price = price;
        this.stock = stock;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    @Override
    public String toString() {
        return id + " | " + name + " | " + category + " | " + price + " | stock: " + stock;
    }
}
